# 02 — 架構：三席模式

## 席位設計（Chuck 指定：唔同 AI agent 各坐一位）

| 席位 | Agent | Model | 專長視角 | 接入方法 |
|------|-------|-------|---------|---------|
| Seat A | **Claude** | Opus 5.5（ai1 機 desktop「Claude.Ai2-HK」）| 治理/倫理/法律 | MRC 遠端打字 |
| Seat B | **Claw** | MiMo v2.6 Pro（Mac mini）| 主持/數據/策略/綜合 | 本地 |
| Seat C | **ai1** | qwen3.8-flash（ai1 機 OpenClaw）| 信貸/資金流/量化 | MRC → PowerShell `openclaw agent` |

## 重要設計決定

### 點解唔係同一個 model 分飾多角？
Trial #1 用 MiMo 分飾三角 → 快但有**共同偏見**風險。Chuck 要求真多元化：三個唔同 brain、三款唔同 model。

### 點解同一份數據 brief？
避免「各自搵料、各說各話」。對立靠**立場 prompt** 營造，唔係靠資訊差。

### Session 分類規則（Johnson 指定）
- 每個 project / 每 round 用獨立 session 或 label（`openpanel-*`）
- 續談時 reuse 同一 session key → 席位記得自己之前嘅立場，可以互相「反口」
- 主 session 只做協調

## 事實紀錄
- Trial #2 起：Claude 同 ai1 嘅對話係**連續劇式**（同一 chat / 同一 session key 續談）
- Claude Code v2.1.322 已裝喺 mini 同 ai1（但 mini 直連 api.anthropic.com 403 — 香港區被擋，經 ai1 走 relay 先得）
- vncdo 教訓見 [[21-Tools-Lessons]]

相關：[[01-Concept]] ｜ [[03-Logic-Flow]]
